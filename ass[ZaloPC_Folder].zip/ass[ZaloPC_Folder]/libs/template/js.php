
<script src="../libs/js/jquery-3.2.1.slim.min.js" ></script>
<script src="../libs/js/popper.min.js" ></script>
<script src="../libs/js/bootstrap.min.js" ></script>