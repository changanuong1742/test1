<?php 

require_once 'BaseModel.php';

class Product extends BaseModel
{
    protected $tableName = 'products';
}

// echo '<pre>';
// $product1 = new Products();
// print_r($product1->all());

?>