<?php 

if(!empty($_POST)){
    $arr = $_POST;
    $image = $_FILES['image'];

    // Thêm giờ hiện tại vào biến created_at
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $arr['created_at'] = date('Y/m/d H:i:s');
    // die($arr['created_at']);

    // Thêm ảnh
    if($image['size']>0){
        $arr['image'] = "upload/" . uniqid() .'-'. $image['name'];
        move_uploaded_file($image['tmp_name'], "../" . $arr['image']);
    }

    $productObj->insert($arr);
    header('location:'.PATH_ROOT);
} else {
    header('location:'.PATH_ROOT);
}

?>