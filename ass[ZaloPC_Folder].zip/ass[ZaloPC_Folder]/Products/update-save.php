<?php 

if(!empty($_POST) && !empty($_GET['id'])){
    $arr = $_POST;
    $id = $_GET['id'];
    $image = $_FILES['image'];
    if(!empty($image['name'])){
        // Thêm ảnh
        if($image['size']>0){
            $arr['image'] = "upload/" . uniqid() .'-'. $image['name'];
            move_uploaded_file($image['tmp_name'], "../" . $arr['image']);
        }
    } else {
        $product = Product::where(['id','=',$id])->first();
        $arr['image'] = $product->image;
    }

    // Thêm giờ hiện tại vào biến created_at
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $arr['updated_at'] = date('Y/m/d H:i:s');


    // Gán id cho đối tượng
    $productObj->id = $id;
    $productObj->update($arr);
    header('location:'.PATH_ROOT);
} else {
    header('location:'.PATH_ROOT);
}

?>