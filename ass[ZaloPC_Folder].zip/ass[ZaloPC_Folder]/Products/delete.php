<?php 
    
?>
<h1 class="mt-3">
    <span>Delete Product</span>  
    <a href="?page=add" class="btn btn-primary float-right mt-2 mr-3">Add Product</a>
</h1>
<?php 

if(!empty($_GET['id'])){
    $id = $_GET['id'];
    Product::destroy($id);
    header('location:'.PATH_ROOT);
} else {
    header('location:'.PATH_ROOT);
}


?>
