<?php 

?>
<h1 class="mt-3">
    <span>View All product</span>  
    <a href="?page=add" class="btn btn-primary float-right mt-2 mr-3">Add Product</a>
</h1>


<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Image</th>
            <th scope="col">CateID</th>
            <th scope="col">Price</th>
            <th scope="col">Short Desc</th>
            <th scope="col">Detail</th>
            <th scope="col">Star</th>
            <th scope="col">Create At</th>
            <th scope="col">Update At</th>
            <th scope="col">Views</th>
            <th scope="col"> Edit </th>
            <!-- <th scope="col">Add Product</th> -->
        </tr>
    </thead>
    <tbody>
        <?php foreach($products as $p): ?>
            <?php $cate = Category::where(['id','=',$p->cate_id])->first(); ?>
            <tr>
                <th scope="row"><?php echo $p->id; ?></th>
                <td style="width: 100px;"> <?php echo $p->name; ?> </td>
                <td> <img width="70px" src="<?php echo PATH_ROOT.$p->image ?>" alt="image"></td>
                <td> <?php echo $cate->cate_name; ?> </td>
                <td> <?php echo $p->price; ?> </td>
                <td style="width: 270px;"> <?php echo $p->short_desc; ?> </td>
                <td style="width: 270px;"> <?php echo $p->detail; ?> </td>
                <td> <?php echo $p->star; ?> </td>
                <td> <?php echo $p->created_at; ?> </td>
                <td> <?php echo $p->updated_at; ?> </td>
                <td> <?php echo $p->views; ?> </td>
                <td style="width: 185px;">
                    <a href="?page=update&id=<?php echo $p->id?>" class="btn btn-success">Update</a>
                    <a href="?page=delete&id=<?php echo $p->id?>" class="btn btn-danger" onclick="javascript:return confirm('Xóa luôn!')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        
    </tbody>

</table>