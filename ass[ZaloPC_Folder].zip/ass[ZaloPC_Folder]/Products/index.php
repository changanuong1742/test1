<?php 
require_once '../Product.php';
require_once '../Category.php';
require_once '../utils.php';
?>
<!doctype html>
<html lang="en">
<!-- head -->
<?php  require_once '../libs/template/head.php' ?>

<body>
    
    <?php
        $page = !empty($_GET['page']) ? $_GET['page'] : 'viewAll';

        switch ($page) 
        {
            case 'viewAll': 
                $products = Product::all();
                require_once 'viewAll.php'; 
                break;
            case 'add': 
                $cates = Category::all();
                require_once 'add.php'; 
                break;
            case 'add-save': 
                $productObj = new Product();
                require_once 'add-save.php'; 
                break;
            case 'update': 
                $cates = Category::all();
                require_once 'update.php'; 
                break;
            case 'update-save':
                $productObj = new Product();
                require_once 'update-save.php'; 
                break;
            case 'delete': require_once 'delete.php'; break;
            default: echo 'error - 404'; break;
        }
    ?>

</body>
<!-- js -->
<?php  require_once '../libs/template/js.php' ?>
</html>
