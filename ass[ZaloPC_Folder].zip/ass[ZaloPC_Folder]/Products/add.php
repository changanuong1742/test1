<h1 class="mt-3">
    <span>Add Product</span>  
    <a href="?page=" class="btn btn-primary float-right mt-2 mr-3">List Product</a>
</h1>

<div class="container-fluid">
    <form action="?page=add-save" method="POST" enctype="multipart/form-data">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="name">Name</label>
                <input type="text" class="form-control" placeholder="Name" name="name" required>
            </div>
            <div class="form-group col-md-6">
                <label for="price">Price</label>
                <input type="number" class="form-control" placeholder="Price" min="0" name="price" required>
            </div>
        </div>
        <div class="form-group">
            <label for="short_desc">Short desc</label>
            <input type="text" class="form-control" placeholder="Short desc" name="short_desc" required>
        </div>
        <div class="form-group">
            <label for="detail">Detail</label>
            <input type="text" class="form-control" placeholder="Detail" name="detail" required>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="image">Image</label>
                <input type="file" class="form-control" name="image" required>
            </div>
            <div class="form-group col-md-4">
                <label for="cate">Category</label>
                <select id="cate" class="form-control">
                    <?php foreach($cates as $c): ?>
                        <option selected value="<?php echo $c->id; ?>"><?php echo $c->cate_name; ?></option>\
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group col-md-2">
                <input type="text" class="form-control" name="created_at" hidden>
            </div>
        </div>
        <button type="submit" class="btn btn-primary float-right">Add now!</button>
    </form>
</div>