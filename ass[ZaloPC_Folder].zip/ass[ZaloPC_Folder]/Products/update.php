<?php 
if(!empty($_GET['id'])){
    $id = $_GET['id'];
    $products = Product::where(['id','=',$id])->first();
    if(empty($products)){
        header('Location:' . PATH_ROOT);
    }
} else {
    header('Location:' . PATH_ROOT);
}

?>
<h1 class="mt-3">
    <span>Update Product</span>  
    <a href="?page=add" class="btn btn-success float-right mt-2 mr-3">Add Product</a>
    <a href="?page=viewAll" class="btn btn-primary float-right mt-2 mr-3">List Product</a>
</h1>

<div class="container-fluid">
    <form action="?page=update-save&id=<?php echo $products->id; ?>" method="POST" enctype="multipart/form-data">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="name">Name</label>
                <input type="text" class="form-control" placeholder="Name" name="name" required value="<?php echo $products->name; ?>">
            </div>
            <div class="form-group col-md-6">
                <label for="price">Price</label>
                <input type="number" class="form-control" placeholder="Price" min="0" name="price" required  value="<?php echo $products->price; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="short_desc">Short desc</label>
            <input type="text" class="form-control" placeholder="Short desc" name="short_desc" required  value="<?php echo $products->short_desc; ?>">
        </div>
        <div class="form-group">
            <label for="detail">Detail</label>
            <input type="text" class="form-control" placeholder="Detail" name="detail" required  value="<?php echo $products->detail; ?>">
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="image">Image</label>
                <input type="file" class="form-control" name="image">
            </div>
            <div class="form-group col-md-4">
                <label for="cate">Category</label>
                <select id="cate" class="form-control">
                    <?php foreach($cates as $c): ?>
                        <?php  if($products->cate_id == $c->id): ?>
                            <option selected value="<?php echo $c->id; ?>"><?php echo $c->cate_name; ?></option>
                        <?php else: ?>
                            <option value="<?php echo $c->id; ?>"><?php echo $c->cate_name; ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group col-md-2">
                <input type="text" class="form-control" name="updated_at" hidden>
            </div>
        </div>
        <button type="submit" class="btn btn-primary float-right">Update now!</button>
    </form>
</div>