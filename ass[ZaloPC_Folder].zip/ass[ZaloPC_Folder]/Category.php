<?php 
require_once 'BaseModel.php';

class Category extends BaseModel
{
    protected $tableName = 'categories';
}
?>