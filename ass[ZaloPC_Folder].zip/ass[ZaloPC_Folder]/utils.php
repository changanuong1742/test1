<?php 

define('PATH_ROOT', 'http://localhost:81/php2/ass/');

?>