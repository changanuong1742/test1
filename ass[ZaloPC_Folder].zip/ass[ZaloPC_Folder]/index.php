<?php 

header("location:Products/");   

?>